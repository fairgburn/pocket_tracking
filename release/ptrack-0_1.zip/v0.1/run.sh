#!/bin/sh

java -jar bin/pocket_tracking.jar
